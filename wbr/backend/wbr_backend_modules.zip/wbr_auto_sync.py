#!/usr/bin/env python3
"""Opt-in periodic WBR provider sync runner.

Runs the existing server-side provider adapter on a conservative interval.
Secrets stay in environment variables. Missing credentials are reported as
not_configured; this runner never fabricates data or retries aggressively.
"""
from __future__ import annotations
import datetime as dt, json, os, signal, subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("WBR_DATA_DIR", str(HERE / "data"))).resolve()
INTERVAL = max(900, int(os.environ.get("WBR_SYNC_INTERVAL_SECONDS", "3600")))
STATUS = ROOT / "auto_sync_status.json"
LOCK = ROOT / "auto_sync.lock"
STOP = False

def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def write_status(obj):
    ROOT.mkdir(parents=True, exist_ok=True)
    tmp = STATUS.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(STATUS)
def stop_handler(*_):
    global STOP
    STOP = True

def main():
    signal.signal(signal.SIGTERM, stop_handler)
    signal.signal(signal.SIGINT, stop_handler)
    ROOT.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.write(fd, str(os.getpid()).encode())
    except FileExistsError:
        print('WBR auto-sync already appears to be running; refusing duplicate runner.')
        return 2
    state = {"enabled": True, "interval_seconds": INTERVAL, "started_at": now(),
             "last_started_at": None, "last_finished_at": None,
             "last_exit_code": None, "runs": 0,
             "note": "Opt-in periodic sync. Provider status is only confirmed after a real request."}
    write_status(state)
    try:
        while not STOP:
            state["last_started_at"] = now()
            write_status(state)
            try:
                result = subprocess.run([sys.executable, str(HERE / 'wbr_provider_sync.py')],
                                        cwd=str(HERE), env=os.environ.copy(),
                                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        text=True, timeout=max(300, INTERVAL - 30))
                # Store a compact, secret-free summary; adapter output never prints key values.
                try:
                    parsed = json.loads(result.stdout)
                    report = parsed.get('source_status', {})
                    state['last_report'] = {
                        'sources': report.get('sources', []),
                        'errors': report.get('errors', []),
                        'matches_total': parsed.get('matches_total'),
                        'odds_total': parsed.get('odds_total')}
                except Exception:
                    state['last_report'] = {"output_tail": result.stdout[-1200:]}
                state['last_exit_code'] = result.returncode
            except subprocess.TimeoutExpired:
                state['last_exit_code'] = 124
                state['last_report'] = {"errors": [{"error": "sync_timeout"}]}
            except Exception as exc:
                state['last_exit_code'] = 1
                state['last_report'] = {"errors": [{"error": type(exc).__name__}]}
            state['last_finished_at'] = now()
            state['runs'] += 1
            write_status(state)
            deadline = time.monotonic() + INTERVAL
            while not STOP and time.monotonic() < deadline:
                time.sleep(min(5, max(0, deadline - time.monotonic())))
    finally:
        state['enabled'] = False
        state['stopped_at'] = now()
        write_status(state)
        try: LOCK.unlink()
        except FileNotFoundError: pass
    return 0

if __name__ == '__main__': raise SystemExit(main())
