#!/usr/bin/env python3
"""WBR read-only backend bridge. No API secrets are exposed to the browser.

This is an integration scaffold, not a deployed service. It serves only verified
local snapshots and research outputs. Provider adapters must be added server-side.
"""
from __future__ import annotations
import csv, json, os, time
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from wbr_canonical import normalize_match, resolve_matches

ROOT = Path(os.environ.get("WBR_DATA_DIR", "./data")).resolve()
HOST = os.environ.get("WBR_BIND_HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", os.environ.get("WBR_PORT", "8787")))
ALLOWED_ORIGIN = os.environ.get("WBR_ALLOWED_ORIGIN", "")

def read_json(path: Path):
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None

def source_status():
    report = read_json(ROOT / "source_status.json") or {}
    return {
        "generated_at": report.get("generated_at"),
        "sources": report.get("sources", []),
        "note": "Only entries in source_status.json are reported. No implicit live status."
    }

def load_matches():
    data = read_json(ROOT / "matches.json")
    return data if isinstance(data, list) else []

def load_odds():
    data = read_json(ROOT / "odds.json")
    return data if isinstance(data, list) else []

def load_forecasts():
    data = read_json(ROOT / "forecasts.json")
    return data if isinstance(data, list) else []

def freshness(row, max_age_seconds=600):
    stamp = row.get("retrieved_at_utc") or row.get("observed_at_utc")
    if not stamp:
        return "unknown"
    try:
        from datetime import datetime, timezone
        dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        age = (datetime.now(timezone.utc) - dt).total_seconds()
        return "fresh" if -60 <= age <= max_age_seconds else "stale"
    except Exception:
        return "unknown"


def match_odds_to_fixtures(matches, odds):
    """Join only exact provider + provider event ID + competition + season keys."""
    import hashlib
    exact = {}
    enriched_matches = []
    for row in matches:
        item = dict(row)
        provider = row.get("provider") or row.get("source") or row.get("provider_name") or "unknown"
        native = row.get("provider_match_id") or row.get("match_id") or row.get("event_id")
        comp = row.get("competition_id") or row.get("competition") or row.get("league_id")
        season = row.get("season")
        if native and comp and season:
            key = (str(provider), str(native), str(comp), str(season))
            # Stable ID for this exact source event. This does not infer cross-provider identity.
            wbr_id = row.get("wbr_match_id") or "wbr_src_" + hashlib.sha256("|".join(key).encode()).hexdigest()[:16]
            exact[key] = wbr_id
            item["wbr_match_id"] = wbr_id
            item["match_identity_status"] = "EXACT_SOURCE_IDENTITY"
        else:
            item["wbr_match_id"] = None
            item["match_identity_status"] = "MISSING_SOURCE_IDENTITY"
        enriched_matches.append(item)
    out = []
    for row in odds:
        item = dict(row)
        provider = row.get("provider") or row.get("source") or row.get("provider_name") or "unknown"
        native = row.get("provider_match_id") or row.get("match_id") or row.get("event_id")
        comp = row.get("competition_id") or row.get("competition") or row.get("league_id")
        season = row.get("season")
        key = (str(provider), str(native), str(comp), str(season)) if native and comp and season else None
        wbr_id = exact.get(key) if key else None
        item["wbr_match_id"] = wbr_id
        item["match_link_status"] = "MATCHED_EXACT_PROVIDER_ID" if wbr_id else (
            "UNMATCHED_MISSING_IDENTITY" if not key else "UNMATCHED_NO_EXACT_FIXTURE"
        )
        out.append(item)
    return {
        "count": len(out),
        "matched": sum(x["wbr_match_id"] is not None for x in out),
        "unmatched": sum(x["wbr_match_id"] is None for x in out),
        "odds": out,
        "matches": enriched_matches,
        "matches_with_stable_ids": sum(x["wbr_match_id"] is not None for x in enriched_matches),
        "matches_missing_identity": sum(x["wbr_match_id"] is None for x in enriched_matches),
        "note": "Only exact provider ID + competition + season joins. No team-name or date fuzzy matching. Match and odds rows share the same stable WBR ID."
    }

class Handler(BaseHTTPRequestHandler):
    server_version = "WBRBridge/0.1"
    def _send(self, code, payload):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        if ALLOWED_ORIGIN and self.headers.get("Origin") == ALLOWED_ORIGIN:
            self.send_header("Access-Control-Allow-Origin", ALLOWED_ORIGIN)
            self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204)
        if ALLOWED_ORIGIN and self.headers.get("Origin") == ALLOWED_ORIGIN:
            self.send_header("Access-Control-Allow-Origin", ALLOWED_ORIGIN)
            self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/v1/health":
            return self._send(200, {"ok": True, "service": "wbr-backend-bridge", "data_dir_exists": ROOT.exists()})
        if path == "/api/v1/importer/status":
            report = read_json(ROOT / "WBR_v1.16.0_import_report.json") or {}
            summary = report.get("summary") if isinstance(report, dict) else None
            return self._send(200, {
                "importer": "WBR v1.16.0",
                "season": "2026/27",
                "report_found": bool(report),
                "summary": summary,
                "generated_at": report.get("generated_at") if isinstance(report, dict) else None,
                "source_license": "NON-COMMERCIAL / informational research only",
                "note": "No import is started by this read-only endpoint. Run the importer manually on the backend host."
            })
        if path == "/api/v1/sync/status":
            status = read_json(ROOT / "auto_sync_status.json") or {}
            configured = True  # SportScore is a public no-key fixture source; other adapters still require secrets.
            return self._send(200, {"runner": status, "credentials_configured": configured,
                "sportscore_public_source": True, "note": "A running scheduler is not proof of provider connectivity. Check last_report and source timestamps."})
        if path == "/api/v1/sources":
            return self._send(200, source_status())
        if path == "/api/v1/odds/normalization-status":
            report = read_json(ROOT / "WBR_V16_NORMALIZE_REPORT.json") or {}
            return self._send(200, {
                "report_found": bool(report),
                "matches_written": report.get("matches_written"),
                "odds_rows_written": report.get("odds_rows_written"),
                "competitions_with_odds_files": report.get("competitions_with_odds_files"),
                "note": "A normalized snapshot is not a live odds feed or a verified model-value signal."
            })
        if path == "/api/v1/providers":
            registry = read_json(Path(__file__).with_name("provider_registry.json")) or {}
            report = read_json(ROOT / "source_status.json") or {}
            observed = {x.get("provider"): x for x in report.get("sources", []) if isinstance(x, dict)}
            providers = []
            for item in registry.get("providers", []):
                row = dict(item)
                live = observed.get(row.get("provider_name"))
                if live:
                    row["last_attempt"] = live
                    row["status"] = live.get("status", row.get("status"))
                providers.append(row)
            return self._send(200, {"count": len(providers), "providers": providers,
                "note": "Registry entries are not proof of a live connection; status requires a recorded provider attempt."})
        if path == "/api/v1/matches":
            rows = load_matches()
            return self._send(200, {"count": len(rows), "matches": rows})
        if path == "/api/v1/odds":
            rows = load_odds()
            return self._send(200, {"count": len(rows), "odds": rows,
                "warning": "Odds are not evidence of model value without a matching approved forecast."})
        if path == "/api/v1/odds/matched":
            return self._send(200, match_odds_to_fixtures(load_matches(), load_odds()))
        if path == "/api/v1/matches/canonical":
            raw = load_matches()
            normalized = [normalize_match(x, x.get("provider") or x.get("source") or x.get("provider_name") or "unknown") for x in raw]
            return self._send(200, resolve_matches(normalized))
        if path == "/api/v1/forecasts":
            rows = load_forecasts()
            return self._send(200, {"count": len(rows), "forecasts": rows,
                "warning": "Research outputs remain research-only unless individually approved."})
        return self._send(404, {"error": "not_found"})
    def log_message(self, fmt, *args):
        # Avoid logging query strings or credentials.
        print("WBR", self.command, self.path.split("?")[0], args[1] if len(args)>1 else "")

if __name__ == "__main__":
    ROOT.mkdir(parents=True, exist_ok=True)
    print(f"WBR backend bridge listening on {HOST}:{PORT}; data={ROOT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
