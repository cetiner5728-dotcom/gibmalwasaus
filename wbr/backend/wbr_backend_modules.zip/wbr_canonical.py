"""WBR canonical multi-provider layer.

Conservative identity resolution: provider IDs are never equated across providers.
Only explicit crosswalks or a high-confidence match key (competition, teams,
kickoff within tolerance) can link records. Conflicting facts are retained.
"""
from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
import json, re
from typing import Any

SCHEMA_VERSION="wbr-canonical-1.0"
VALID_STATUSES={"scheduled","live","finished","postponed","cancelled","unknown"}

def _norm(s: Any) -> str:
    return re.sub(r"\s+"," ",str(s or "").strip().casefold())

def _utc(s: Any):
    if not s: return None
    try:
        d=datetime.fromisoformat(str(s).replace("Z","+00:00"))
        if d.tzinfo is None: return None
        return d.astimezone(timezone.utc)
    except Exception: return None

def _id(provider: str, native_id: Any) -> str:
    return f"{provider}:{native_id}" if native_id not in (None,"") else ""

def normalize_match(row: dict, provider: str) -> dict:
    """Map already-fetched provider record to canonical fields; preserve raw."""
    kickoff=row.get("kickoff_utc") or row.get("kickoffUtc") or row.get("date_utc") or row.get("date")
    status=_norm(row.get("status") or "unknown").replace(" ","_")
    if status not in VALID_STATUSES:
        # retain unfamiliar upstream status separately, do not guess its meaning
        upstream_status=status; status="unknown"
    else: upstream_status=None
    home=row.get("home_team_original") or row.get("home_team") or row.get("homeTeam") or row.get("home")
    away=row.get("away_team_original") or row.get("away_team") or row.get("awayTeam") or row.get("away")
    native=row.get("source_match_id") or row.get("provider_match_id") or row.get("id") or row.get("fixture_id")
    season=row.get("season")
    return {
      "schema_version":SCHEMA_VERSION,
      "wbr_match_id":None,
      "sport":row.get("sport"),
      "season":season,
      "competition_id":None,
      "competition_name":row.get("competition_name") or row.get("competition") or row.get("league_name") or row.get("league"),
      "competition_country":row.get("competition_country") or row.get("league_country"),
      "provider_name":provider,
      "provider_match_id":str(native) if native not in (None,"") else None,
      "provider_match_key":_id(provider,native) or None,
      "provider_league_id":row.get("provider_league_id") or row.get("league_id"),
      "provider_home_team_id":row.get("home_team_id") or row.get("home_id"),
      "provider_away_team_id":row.get("away_team_id") or row.get("away_id"),
      "kickoff_source_raw":kickoff,
      "kickoff_utc":_utc(kickoff).isoformat().replace("+00:00","Z") if _utc(kickoff) else None,
      "home_team_original":home,"away_team_original":away,
      "home_team_key":_norm(home) or None,"away_team_key":_norm(away) or None,
      "status":status,"upstream_status":upstream_status or row.get("status"),
      "ft_home":row.get("ft_home",row.get("home_score")),
      "ft_away":row.get("ft_away",row.get("away_score")),
      "ht_home":row.get("ht_home"),"ht_away":row.get("ht_away"),
      "stats_json":row.get("stats_json") or row.get("statistics"),
      "retrieved_at_utc":row.get("retrieved_at_utc") or datetime.now(timezone.utc).isoformat().replace("+00:00","Z"),
      "source_updated_at_utc":row.get("source_updated_at_utc") or row.get("updated_at"),
      "license_tag":row.get("license_tag"),
      "quality_flags":[],
      "raw":row
    }

def _match_key(m: dict, tolerance_minutes=5):
    t=_utc(m.get("kickoff_utc"))
    if not t or not m.get("home_team_key") or not m.get("away_team_key") or not m.get("competition_name"):
        return None
    # Minute bucket intentionally strict; resolver later checks actual tolerance.
    bucket=int(t.timestamp()//(tolerance_minutes*60))
    return (_norm(m.get("sport")), _norm(m.get("season")), _norm(m.get("competition_name")),
            m["home_team_key"],m["away_team_key"],bucket)

def resolve_matches(records: list[dict], crosswalk: dict|None=None, tolerance_minutes=5):
    """Return canonical matches and unresolved pairs; no name-only auto-merge."""
    crosswalk=crosswalk or {}
    groups=[]; unresolved=[]
    by_provider_key={}
    for r in records:
        pkey=r.get("provider_match_key")
        if pkey and pkey in crosswalk:
            wid=crosswalk[pkey]
            target=next((g for g in groups if g["wbr_match_id"]==wid),None)
            if target is None:
                target={"wbr_match_id":wid,"provider_records":[]};groups.append(target)
            target["provider_records"].append(r); by_provider_key[pkey]=target
            continue
        key=_match_key(r)
        if key is None:
            unresolved.append({"reason":"MISSING_IDENTITY_FIELDS","provider":r.get("provider_name"),"provider_match_key":pkey})
            continue
        found=None
        for g in groups:
            first=g["provider_records"][0]
            if _match_key(first)!=key: continue
            a=_utc(first.get("kickoff_utc")); b=_utc(r.get("kickoff_utc"))
            if a and b and abs((a-b).total_seconds())<=tolerance_minutes*60:
                # Do not auto-merge two records from the same provider unless same native id.
                if first.get("provider_name")==r.get("provider_name"):
                    if first.get("provider_match_key")==pkey: found=g
                    else: continue
                else: found=g
                break
        if found is None:
            wid="wbr_"+sha256("|".join(map(str,key)).encode()).hexdigest()[:16]
            found={"wbr_match_id":wid,"provider_records":[]};groups.append(found)
        found["provider_records"].append(r)
        if pkey: by_provider_key[pkey]=found
    for g in groups:
        g["provider_keys"]=sorted({x["provider_match_key"] for x in g["provider_records"] if x.get("provider_match_key")})
        g["providers"]=sorted({x["provider_name"] for x in g["provider_records"]})
        g["conflicts"]=detect_conflicts(g["provider_records"])
    return {"matches":groups,"unresolved":unresolved}

def detect_conflicts(records: list[dict]) -> list[dict]:
    conflicts=[]
    for field in ("status","ft_home","ft_away","ht_home","ht_away","kickoff_utc"):
        vals=[]
        for r in records:
            v=r.get(field)
            if v is not None and v not in vals: vals.append(v)
        if len(vals)>1:
            conflicts.append({"field":field,"values":[{"provider":r.get("provider_name"),"value":r.get(field),"retrieved_at_utc":r.get("retrieved_at_utc")} for r in records if r.get(field) is not None]})
    return conflicts

def normalize_odds(row: dict, provider: str) -> dict:
    return {
      "schema_version":SCHEMA_VERSION,"provider_name":provider,
      "provider_event_id":row.get("event_id") or row.get("match_id") or row.get("fixture_id"),
      "bookmaker":row.get("bookmaker"),"market":row.get("market"),
      "period":row.get("period"),"selection":row.get("selection") or row.get("outcome"),
      "line":row.get("line"),"odds_decimal":row.get("odds_decimal",row.get("odds")),
      "observed_at_utc":row.get("observed_at_utc") or row.get("retrieved_at_utc"),
      "is_live":row.get("is_live",row.get("in_play")),
      "is_opening":row.get("is_opening",False),"is_closing":row.get("is_closing",False),
      "raw_quote_id":row.get("raw_quote_id") or row.get("selection_id"),
      "raw":row
    }

def provider_health(name: str, state: dict) -> dict:
    """No inferred healthy state; only explicit last attempt is reported."""
    return {"provider_name":name,"enabled":bool(state.get("enabled",False)),
      "last_success_at":state.get("last_success_at"),"last_error_at":state.get("last_error_at"),
      "last_error_code":state.get("last_error_code"),"quota_daily_limit":state.get("quota_daily_limit"),
      "quota_remaining":state.get("quota_remaining"),"coverage_last_checked_at":state.get("coverage_last_checked_at"),
      "status":state.get("status","NOT_TESTED"),"schema_version":state.get("schema_version",SCHEMA_VERSION)}
