"""Materialize a canonical WBR schedule view from the multi-provider snapshot."""
from __future__ import annotations
from wbr_canonical import normalize_match, resolve_matches

def build_canonical_schedule(source_rows, tolerance_minutes=5):
    if not isinstance(source_rows, list):
        raise ValueError("source_rows must be a JSON list")
    normalized=[]
    for row in source_rows:
        if not isinstance(row,dict):
            continue
        provider=row.get("provider") or row.get("source") or row.get("provider_name") or "unknown"
        normalized.append(normalize_match(row,str(provider)))
    resolved=resolve_matches(normalized,tolerance_minutes=tolerance_minutes)
    schedule=[]
    for group in resolved["matches"]:
        records=group.get("provider_records",[])
        # Keep every source record; top-level display fields are conservative,
        # using first non-empty value and retaining conflicts separately.
        def first_value(*keys):
            for rec in records:
                for key in keys:
                    val=rec.get(key)
                    if val not in (None,""):
                        return val
            return None
        schedule.append({
            "wbr_match_id":group["wbr_match_id"],
            "sport":first_value("sport"),
            "season":first_value("season"),
            "competition_name":first_value("competition_name","competition","league"),
            "kickoff_utc":first_value("kickoff_utc","kickoffUtc","date_utc","date"),
            "home_team":first_value("home_team_original","home_team","homeTeam","home"),
            "away_team":first_value("away_team_original","away_team","awayTeam","away"),
            "providers":group.get("providers",[]),
            "provider_keys":group.get("provider_keys",[]),
            "provider_records":records,
            "conflicts":group.get("conflicts",[])
        })
    schedule.sort(key=lambda x: (str(x.get("kickoff_utc") or ""),str(x.get("competition_name") or "")))
    return {
        "count":len(schedule),
        "source_record_count":len(normalized),
        "unresolved_count":len(resolved["unresolved"]),
        "unresolved":resolved["unresolved"],
        "matches":schedule,
        "identity_policy":"Cross-provider grouping requires same sport, season, competition, home/away teams and kickoff within tolerance; no name-only matching."
    }
