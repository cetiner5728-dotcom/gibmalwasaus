#!/usr/bin/env python3
"""Safe importer for WBR JSON exports into the shared matches snapshot."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from typing import Any

KEY_FIELDS = ("source", "provider", "provider_match_id", "id", "competition_name", "season")

def identity(row: dict) -> tuple[str, ...]:
    provider = str(row.get("source") or row.get("provider") or "unknown").strip().casefold()
    native = row.get("provider_match_id") or row.get("provider_event_id") or row.get("id")
    competition = str(row.get("competition_name") or row.get("competition") or "").strip().casefold()
    season = str(row.get("season") or "").strip()
    # Native IDs are scoped to provider + competition + season; never merge across leagues.
    if native not in (None, ""):
        return (provider, str(native), competition, season)
    # No native ID: require full fixture identity; otherwise do not silently merge.
    kickoff = str(row.get("kickoff_utc") or row.get("kickoff") or "").strip()
    home = str(row.get("homeTeam") or row.get("home_team") or "").strip().casefold()
    away = str(row.get("awayTeam") or row.get("away_team") or "").strip().casefold()
    return (provider, competition, season, kickoff, home, away)

def merge(existing: list[dict], incoming: list[dict]) -> tuple[list[dict], dict]:
    out=[]; positions={}; added=updated=0
    for row in existing:
        if not isinstance(row,dict): continue
        key=identity(row)
        if any(key):
            if key in positions:
                # Keep first occurrence; duplicate old rows are not propagated.
                continue
            positions[key]=len(out)
        out.append(dict(row))
    for row in incoming:
        if not isinstance(row,dict): continue
        key=identity(row)
        if not any(key): continue
        if key not in positions:
            positions[key]=len(out); out.append(dict(row)); added+=1
        else:
            idx=positions[key]; merged=dict(out[idx])
            for k,v in row.items():
                if v is not None and v != "": merged[k]=v
            out[idx]=merged; updated+=1
    return out,{"existing_after_dedupe":len(existing),"incoming_valid":sum(isinstance(x,dict) for x in incoming),"added":added,"updated":updated,"total":len(out)}

def load_rows(path: Path) -> list[dict]:
    obj=json.loads(path.read_text(encoding="utf-8"))
    rows=obj.get("matches",[]) if isinstance(obj,dict) else obj
    if not isinstance(rows,list): raise ValueError("Export muss eine matches-Liste enthalten")
    return [x for x in rows if isinstance(x,dict)]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("export"); ap.add_argument("--data-dir",default="./data")
    a=ap.parse_args(); root=Path(a.data_dir); root.mkdir(parents=True,exist_ok=True)
    target=root/"matches.json"; old=json.loads(target.read_text()) if target.exists() else []
    if not isinstance(old,list): raise ValueError("matches.json ist keine Liste")
    rows=load_rows(Path(a.export)); merged,stats=merge(old,rows)
    tmp=target.with_suffix(".json.tmp"); tmp.write_text(json.dumps(merged,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); tmp.replace(target)
    leagues=sorted({str(x.get("competition_name") or x.get("competition") or "Unbekannt") for x in merged})
    sports=sorted({str(x.get("sport") or "Unbekannt") for x in merged})
    print(json.dumps({"status":"ok","stats":stats,"sports":sports,"competitions":len(leagues),"competition_names":leagues},ensure_ascii=False,indent=2))

if __name__=="__main__": main()
