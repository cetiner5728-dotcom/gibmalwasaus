"""Safe multi-provider fixture snapshot upsert for WBR matches.json."""
from __future__ import annotations
from typing import Any

def _provider(row: dict, fallback: str | None = None) -> str:
    return str(row.get("provider") or row.get("source") or row.get("provider_name") or fallback or "unknown").strip().casefold()

def _native_id(row: dict) -> str | None:
    for key in ("provider_match_id", "provider_event_id", "provider_match_key", "match_id", "event_id", "fixture_id", "id"):
        value=row.get(key)
        if value not in (None, ""):
            return str(value)
    return None

def _snapshot_key(row: dict, fallback: str | None = None) -> tuple | None:
    provider=_provider(row,fallback)
    native=_native_id(row)
    if native is None:
        return None
    return provider,native

def merge_fixture_snapshot(existing: Any, incoming: Any, provider: str) -> dict:
    """Upsert only by same-provider native event ID; never equate IDs cross-provider.

    Rows without a native ID are retained as separate incoming records and reported
    unresolved; no fuzzy team-name join is attempted here.
    """
    if existing is None: existing=[]
    if not isinstance(existing,list): raise ValueError("matches.json must contain a JSON list")
    if not isinstance(incoming,list): raise ValueError("incoming fixtures must be a JSON list")
    rows=[dict(x) for x in existing if isinstance(x,dict)]
    positions={}
    for i,row in enumerate(rows):
        key=_snapshot_key(row)
        if key is not None: positions[key]=i
    added=updated=unresolved=0
    unresolved_rows=[]
    for raw in incoming:
        if not isinstance(raw,dict): continue
        row=dict(raw)
        row.setdefault("provider",provider)
        row.setdefault("source",provider)
        key=_snapshot_key(row,provider)
        if key is None:
            unresolved+=1; unresolved_rows.append(row); rows.append(row); added+=1
            continue
        if key in positions:
            # Preserve the original record's non-null metadata if the new poll omits it.
            old=rows[positions[key]]
            merged=dict(old)
            for field,value in row.items():
                if value is not None and value != "":
                    merged[field]=value
            rows[positions[key]]=merged; updated+=1
        else:
            positions[key]=len(rows); rows.append(row); added+=1
    return {"matches":rows,"added":added,"updated":updated,"unresolved":unresolved,
            "unresolved_rows":unresolved_rows,"total_matches":len(rows)}

