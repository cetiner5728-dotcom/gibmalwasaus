"""Convert a MoviOdds response into auditable WBR odds rows.

This module never guesses seasons or silently links a quote to a different fixture.
Cross-provider links use the canonical resolver's strict competition/team/kickoff key.
"""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Any
from wbr_canonical import normalize_match, resolve_matches
from wbr_sources.moviodds import MoviOddsClient


def _as_dict(fixture: Any) -> dict:
    return MoviOddsClient.to_dict(fixture)


def ingest_payload(payload: dict, existing_matches: list[dict], season_by_league: dict[str, str] | None = None) -> dict:
    season_by_league = season_by_league or {}
    rows = payload.get("matches", []) if isinstance(payload, dict) else []
    if not isinstance(rows, list):
        raise ValueError("MoviOdds payload must contain a matches list")
    retrieved = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    movi_matches = []
    quotes_raw = []
    for row in rows:
        if not isinstance(row, dict) or row.get("id") in (None, ""):
            continue
        league = row.get("league")
        season = row.get("season") or season_by_league.get(str(league or ""))
        fixture = {
            "source": "moviodds", "provider": "moviodds",
            "provider_match_id": str(row["id"]), "sport": row.get("sport") or "Football",
            "competition_name": league, "season": season,
            "homeTeam": row.get("home"), "awayTeam": row.get("away"),
            "kickoff_utc": row.get("kickoff_utc"),
            "status": "live" if row.get("in_play") else "scheduled",
            "retrieved_at_utc": row.get("polled_at") or retrieved,
        }
        movi_matches.append(normalize_match(fixture, "moviodds"))
        for quote in row.get("quotes") or []:
            if not isinstance(quote, dict):
                continue
            try:
                price = float(quote.get("odds_dec"))
            except (TypeError, ValueError):
                continue
            if price <= 1.0:
                continue
            quotes_raw.append({
                "provider": "moviodds", "source": "moviodds", "provider_match_id": str(row["id"]),
                "competition_name": league, "season": season,
                "bookmaker": "bet365", "market_id": quote.get("market_id"),
                "market_group_id": quote.get("group_id"), "selection_id": quote.get("sel_id"),
                "selection": quote.get("label"), "odds_decimal": price,
                "observed_at_utc": quote.get("ts") or row.get("polled_at") or retrieved,
                "is_live": bool(row.get("in_play")), "suspended": bool(quote.get("suspended", False)),
                "raw": quote,
            })
    canonical_existing = [normalize_match(x, x.get("provider") or x.get("source") or x.get("provider_name") or "unknown") for x in existing_matches if isinstance(x, dict)]
    resolved = resolve_matches(canonical_existing + movi_matches, tolerance_minutes=5)
    quote_by_provider_key = {}
    for group in resolved["matches"]:
        # A MoviOdds-only group is not proof that the fixture exists in WBR's
        # shared schedule. Require at least one independent fixture provider.
        providers = set(group.get("providers", []))
        if "moviodds" not in providers or len(providers) < 2:
            continue
        wid = group["wbr_match_id"]
        for provider_key in group.get("provider_keys", []):
            quote_by_provider_key[provider_key] = wid
    for quote in quotes_raw:
        provider_key = f"moviodds:{quote['provider_match_id']}"
        wid = quote_by_provider_key.get(provider_key)
        quote["wbr_match_id"] = wid
        quote["match_link_status"] = "MATCHED_CANONICAL_FIXTURE" if wid else "UNMATCHED_REVIEW_REQUIRED"
        if quote["season"] in (None, ""):
            quote["unmatched_reason"] = "MISSING_SEASON"
        elif not quote["competition_name"] or not quote["observed_at_utc"]:
            quote["unmatched_reason"] = "MISSING_COMPETITION_OR_TIMESTAMP"
    return {
        "provider": "MoviOdds", "retrieved_at_utc": retrieved,
        "fixtures_received": len(movi_matches), "quotes_received": len(quotes_raw),
        "matched_quotes": sum(q["wbr_match_id"] is not None for q in quotes_raw),
        "unmatched_quotes": sum(q["wbr_match_id"] is None for q in quotes_raw),
        "unresolved_matches": len(resolved["unresolved"]),
        "odds": quotes_raw, "canonical_resolution": resolved,
        "note": "Only strict canonical competition/team/kickoff matches are linked; no fuzzy team-only matching."
    }
