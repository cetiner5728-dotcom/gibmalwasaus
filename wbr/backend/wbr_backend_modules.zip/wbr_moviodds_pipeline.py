"""End-to-end pure MoviOdds processing pipeline for the WBR POST handler."""
from __future__ import annotations
from datetime import datetime, timezone
from wbr_moviodds_ingest import ingest_payload
from wbr_moviodds_store import merge_moviodds

def process_moviodds_payload(payload: dict, matches: list, existing_odds: list,
                             season_by_league: dict | None = None,
                             retrieved_at_utc: str | None = None) -> dict:
    """Normalize, strictly match, and merge a MoviOdds payload without file I/O."""
    if not isinstance(payload, dict):
        raise ValueError("MoviOdds payload must be a JSON object")
    stamp = retrieved_at_utc or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    ingest = ingest_payload(payload, matches, season_by_league=season_by_league or {})
    merged = merge_moviodds(existing_odds, ingest)
    matched = [x for x in merged["odds"]
               if (x.get("provider") or x.get("source")) == "moviodds" and x.get("wbr_match_id")]
    return {
        "raw_archive": {"retrieved_at_utc": stamp, "payload": payload},
        "odds": merged["odds"],
        "matched_odds": {
            "provider": "MoviOdds", "retrieved_at_utc": stamp,
            "matched_count": len(matched),
            "unmatched_count": len(merged["unmatched_moviodds"]),
            "odds": matched
        },
        "ingest_report": {
            "provider": "MoviOdds",
            "retrieved_at_utc": ingest["retrieved_at_utc"],
            "fixtures_received": ingest["fixtures_received"],
            "quotes_received": ingest["quotes_received"],
            "matched_quotes": ingest["matched_quotes"],
            "unmatched_quotes": ingest["unmatched_quotes"],
            "unresolved_matches": ingest["unresolved_matches"],
            "store_added": merged["added"],
            "store_updated": merged["updated"],
            "store_total_odds": merged["total_odds"],
            "unmatched_rows": merged["unmatched_moviodds"],
            "note": ingest["note"]
        }
    }
