"""Safe, idempotent MoviOdds upsert into WBR odds snapshots."""
from __future__ import annotations
from typing import Any

def _quote_key(row: dict) -> tuple:
    return (
        str(row.get("provider") or row.get("source") or "").lower(),
        str(row.get("provider_match_id") or ""),
        str(row.get("market_id") or ""),
        str(row.get("selection_id") or ""),
        str(row.get("observed_at_utc") or ""),
        str(row.get("bookmaker") or "").lower(),
    )

def merge_moviodds(existing_odds: Any, ingest_report: dict) -> dict:
    """Merge only canonically matched MoviOdds rows; retain all existing providers.

    Unmatched Moviodds rows are returned separately and never enter odds.json.
    Repeated syncs replace the same provider quote key rather than duplicating it.
    """
    if existing_odds is None:
        existing_odds = []
    if not isinstance(existing_odds, list):
        raise ValueError("odds.json must contain a JSON list")
    incoming = ingest_report.get("odds", [])
    if not isinstance(incoming, list):
        raise ValueError("ingest report odds must contain a list")
    retained = [dict(x) for x in existing_odds if isinstance(x, dict)]
    positions = {_quote_key(x): i for i, x in enumerate(retained) if _quote_key(x)[0] == "moviodds"}
    added = updated = 0
    unmatched = []
    for raw in incoming:
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        if not row.get("wbr_match_id"):
            unmatched.append(row)
            continue
        row["provider"] = "moviodds"
        row["source"] = "moviodds"
        row["match_link_status"] = "MATCHED_CANONICAL_FIXTURE"
        key = _quote_key(row)
        if key in positions:
            retained[positions[key]] = row
            updated += 1
        else:
            positions[key] = len(retained)
            retained.append(row)
            added += 1
    return {
        "odds": retained,
        "matched_odds": [x for x in retained if x.get("wbr_match_id")],
        "unmatched_moviodds": unmatched,
        "added": added,
        "updated": updated,
        "total_odds": len(retained),
        "matched_moviodds": sum(1 for x in retained if (x.get("provider") or x.get("source")) == "moviodds" and x.get("wbr_match_id")),
    }
