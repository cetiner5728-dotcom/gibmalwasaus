#!/usr/bin/env python3
"""WBR v1.16 research importer: 75-league discovery plus optional bookmaker odds.

Source: oladeeayo/open-matchday. Research-only: upstream states non-commercial use.
Daily, not live. Odds files exist only for a subset of competitions; no xG,
confirmed lineups or injury feed. Missing cells remain NULL.
"""
from __future__ import annotations
import argparse, csv, io, json, re, time, urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = '1.16.0'
SEASON = '2627'
INDEX_URL = 'https://raw.githubusercontent.com/oladeeayo/open-matchday/master/LEAGUE_INDEX.md'
BASES = [
    'https://raw.githubusercontent.com/oladeeayo/open-matchday/master/data',
    'https://cdn.jsdelivr.net/gh/oladeeayo/open-matchday@master/data',
]
LEAGUES = {
    'ENG_1_premier-league': 'Premier League',
    'ESP_1_la-liga': 'La Liga',
    'GER_1_bundesliga': 'Bundesliga',
    'ITA_1_serie-a': 'Serie A',
    'FRA_1_ligue-1': 'Ligue 1',
    'UEFA_1_champions-league': 'Champions League',
    'UEFA_1_europa-league': 'Europa League',
    'NED_1_eredivisie': 'Eredivisie',
    'POR_1_primeira-liga': 'Primeira Liga',
    'TUR_1_super-lig': 'Süper Lig',
    'ENG_2_championship': 'Championship',
}
RESULT_REQUIRED = {'date','home','away','ft_home','ft_away'}
FIXTURE_REQUIRED = {'date','home','away'}
OPTIONAL_KINDS = ('odds_1x2','odds_markets','odds_fixtures','over25')
STAT_FIELDS = ['ht_home','ht_away','home_shots','away_shots','home_target','away_target',
               'home_corners','away_corners','home_corners_1h','away_corners_1h',
               'home_corners_2h','away_corners_2h','home_yellow','away_yellow']

def fetch(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={'User-Agent': f'WBR/{VERSION} (research importer)',
                                               'Accept': 'text/plain,text/csv,*/*'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    if not data or b'<html' in data[:500].lower() or b'<!doctype' in data[:500].lower():
        raise ValueError('Empty or HTML response; expected text/CSV')
    return data

def discover_leagues(index_text: str) -> dict[str, str]:
    """Parse only actual data-folder rows from upstream LEAGUE_INDEX.md."""
    found: dict[str, str] = {}
    for line in index_text.splitlines():
        m = re.match(r'^\|\s*`([A-Za-z0-9_-]+)`\s*\|\s*([^|]+?)\s*\|', line)
        if m:
            folder, name = m.group(1).strip(), m.group(2).strip()
            if folder and name and folder not in {'Folder'}:
                found[folder] = name
    if len(found) < 12:
        raise ValueError(f'League index parse suspicious: only {len(found)} competition rows found')
    return found

def fetch_csv(folder: str, kind: str) -> tuple[str, bytes, list[str]]:
    filename = f'{kind}_{SEASON}.csv'; errors=[]
    for base in BASES:
        url=f'{base}/{folder}/{filename}'
        try:
            data=fetch(url)
            # Validate UTF-8 and CSV header before accepting the source route.
            decoded=data.decode('utf-8-sig')
            if not decoded.splitlines(): raise ValueError('No CSV lines')
            return url, data, errors
        except Exception as e:
            errors.append(f'{url}: {type(e).__name__}: {e}')
    raise RuntimeError('All source routes failed: ' + ' || '.join(errors))

def read_rows(data: bytes) -> tuple[list[str], list[dict[str, Any]]]:
    reader=csv.DictReader(io.StringIO(data.decode('utf-8-sig')))
    headers=reader.fieldnames or []
    rows=[{k:(v if v not in (None,'') else None) for k,v in row.items()} for row in reader]
    return headers, rows

def check_rows(kind: str, headers: list[str], rows: list[dict[str,Any]]) -> dict[str,Any]:
    required=RESULT_REQUIRED if kind=='results' else FIXTURE_REQUIRED
    missing=sorted(required-set(headers)); errors=[]; seen=set(); duplicates=bad_dates=bad_scores=0
    for r in rows:
        try: datetime.strptime(r.get('date') or '', '%Y-%m-%d')
        except ValueError: bad_dates+=1
        key=(r.get('date'),r.get('home'),r.get('away'))
        if key in seen: duplicates+=1
        seen.add(key)
        if kind=='results':
            for f in ('ft_home','ft_away'):
                try:
                    if int(r.get(f)) < 0: raise ValueError()
                except (TypeError,ValueError): bad_scores+=1
    if missing: errors.append('missing required columns: '+','.join(missing))
    if bad_dates: errors.append(f'{bad_dates} invalid dates')
    if bad_scores: errors.append(f'{bad_scores} invalid/missing full-time score values')
    if duplicates: errors.append(f'{duplicates} duplicate match keys')
    coverage={f:sum(1 for r in rows if r.get(f) is not None) for f in STAT_FIELDS if f in headers}
    dates=[r.get('date') for r in rows if r.get('date')]
    return {'rows':len(rows),'first_date':min(dates) if dates else None,'last_date':max(dates) if dates else None,
            'missing_required_columns':missing,'invalid_dates':bad_dates,'invalid_scores':bad_scores,
            'duplicate_keys':duplicates,'stat_coverage':coverage,'errors':errors,'passed':not errors}

def check_optional_rows(kind: str, headers: list[str], rows: list[dict[str,Any]]) -> dict[str,Any]:
    required = {
        'odds_1x2': {'match_id','bookmaker','home','draw','away'},
        'odds_markets': {'match_id','bookmaker','market','scope','selection','odds'},
        'odds_fixtures': {'match_id','date','home','away','n_books'},
        'over25': {'match_id','p_over25','price_over25','bookmaker'},
    }[kind]
    missing=sorted(required-set(headers)); bad_prices=0; bad_dates=0; duplicates=0; seen=set()
    price_fields = {'odds_1x2':['home','draw','away','home_open','draw_open','away_open'],
                    'odds_markets':['odds','odds_open'],
                    'odds_fixtures':['home_odds','draw_odds','away_odds','btts_yes','over25'],
                    'over25':['price_over25']}[kind]
    for r in rows:
        if kind in ('odds_1x2','odds_markets'):
            key=(r.get('match_id'),r.get('bookmaker'),r.get('market'),r.get('scope'),r.get('line'),r.get('selection')) if kind=='odds_markets' else (r.get('match_id'),r.get('bookmaker'))
            if key in seen: duplicates+=1
            seen.add(key)
        elif kind=='odds_fixtures':
            key=(r.get('match_id'),)
            if key in seen: duplicates+=1
            seen.add(key)
        for field in price_fields:
            value=r.get(field)
            if value not in (None,''):
                try:
                    n=float(value)
                    if not (n>0 and n<100000): raise ValueError()
                except (TypeError,ValueError): bad_prices+=1
        if kind in ('odds_fixtures','over25') and r.get('date'):
            try: datetime.strptime(r['date'],'%Y-%m-%d')
            except ValueError: bad_dates+=1
        if kind=='over25' and r.get('p_over25') not in (None,''):
            try:
                if not 0<=float(r['p_over25'])<=1: raise ValueError()
            except (TypeError,ValueError): bad_prices+=1
    errors=[]
    if missing: errors.append('missing required columns: '+','.join(missing))
    if bad_prices: errors.append(f'{bad_prices} invalid price/probability values')
    if bad_dates: errors.append(f'{bad_dates} invalid dates')
    if duplicates: errors.append(f'{duplicates} duplicate odds keys')
    return {'rows':len(rows),'missing_required_columns':missing,'invalid_prices_or_probabilities':bad_prices,
            'invalid_dates':bad_dates,'duplicate_keys':duplicates,'errors':errors,'passed':not errors}

def run(out: Path, league_map: dict[str,str], selected: list[str] | None=None) -> dict[str,Any]:
    out.mkdir(parents=True,exist_ok=True)
    report={'version':VERSION,'season':SEASON,'generated_utc':datetime.now(timezone.utc).isoformat(),
            'source':'open-matchday','source_index_url':INDEX_URL,
            'source_license':'NON-COMMERCIAL / informational research only; do not use as a commercial feed',
            'purpose':'research-only historical/fixture expansion',
            'important_limitations':['Not live; upstream states daily refresh','Odds files are optional and available only for a subset of competitions; not historical closing-line data', 'No xG',
             'No confirmed lineups or injuries','Statistics/HT fields are sparse and league-dependent',
             'Provider/source rights apply; no redistribution or monetized access'],
            'documentation_note':'Upstream root README limitations say no odds, but data/README.md documents optional odds_* files; actual file presence is checked per competition. Treat this as a documentation inconsistency.', 'leagues':[]}
    for folder,name in league_map.items():
        if selected and folder not in selected: continue
        item={'folder':folder,'league':name,'files':{},'status':'FAILED','errors':[]}
        for kind in ('results','fixtures'):
            try:
                url,data,fetch_errors=fetch_csv(folder,kind)
                headers,rows=read_rows(data); qc=check_rows(kind,headers,rows)
                item['files'][kind]={'url':url,'bytes':len(data),'quality':qc}
                if fetch_errors: item['files'][kind]['fallback_errors']=fetch_errors
                (out/f'{folder}_{kind}_{SEASON}.csv').write_bytes(data)
                if not qc['passed']: item['errors'] += [f'{kind}: {e}' for e in qc['errors']]
            except Exception as e: item['errors'].append(f'{kind}: {type(e).__name__}: {e}')
        for kind in OPTIONAL_KINDS:
            try:
                url,data,fetch_errors=fetch_csv(folder,kind)
                headers,rows=read_rows(data); qc=check_optional_rows(kind,headers,rows)
                item['files'][kind]={'url':url,'bytes':len(data),'quality':qc}
                if fetch_errors: item['files'][kind]['fallback_errors']=fetch_errors
                (out/f'{folder}_{kind}_{SEASON}.csv').write_bytes(data)
                if not qc['passed']: item['errors'] += [f'{kind}: {e}' for e in qc['errors']]
            except Exception as e:
                item.setdefault('optional_unavailable',[]).append(kind)
        rq=item['files'].get('results',{}).get('quality',{})
        fq=item['files'].get('fixtures',{}).get('quality',{})
        if rq.get('passed') and fq.get('passed') and not item['errors']: item['status']='IMPORTED_QC_PASSED'
        elif rq.get('passed') and fq.get('passed'): item['status']='CORE_QC_PASSED_OPTIONAL_QC_FAILED'
        elif item['files']: item['status']='PARTIAL_OR_QC_FAILED'
        report['leagues'].append(item)
    report['summary']={'competitions_requested':len(report['leagues']),
       'competitions_with_both_files_qc_passed':sum(x['status']=='IMPORTED_QC_PASSED' for x in report['leagues']),
       'competitions_failed_or_partial':sum(x['status']!='IMPORTED_QC_PASSED' for x in report['leagues']),
       'competitions_with_1x2_odds':sum('odds_1x2' in x.get('files',{}) and x['files']['odds_1x2']['quality']['passed'] for x in report['leagues']),
       'competitions_with_market_odds':sum('odds_markets' in x.get('files',{}) and x['files']['odds_markets']['quality']['passed'] for x in report['leagues']),
       'odds_rows_1x2':sum(x.get('files',{}).get('odds_1x2',{}).get('quality',{}).get('rows',0) for x in report['leagues']),
       'odds_market_rows':sum(x.get('files',{}).get('odds_markets',{}).get('quality',{}).get('rows',0) for x in report['leagues'])}
    (out/'WBR_v1.16.0_import_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    return report

def self_test():
    sample_lines=['| Folder | League | Country |','|---|---|---|',
      '| `ENG_1_premier-league` | Premier League | England |',
      '| `BRA_1_serie-a` | Brasileirão Série A | Brazil |',
      '| `JPN_1_j1-league` | J1 League | Japan |']
    for i in range(9): sample_lines.append(f'| `TEST_{i}_league-{i}` | Test League {i} | Test |')
    parsed=discover_leagues('\n'.join(sample_lines))
    assert len(parsed)==12 and parsed['BRA_1_serie-a']=='Brasileirão Série A'
    h=['date','home','away','ft_home','ft_away','ht_home']
    good=[{'date':'2026-08-01','home':'A','away':'B','ft_home':'2','ft_away':'1','ht_home':None},
          {'date':'2026-08-08','home':'B','away':'A','ft_home':'0','ft_away':'0','ht_home':'0'}]
    qc=check_rows('results',h,good)
    assert qc['passed'] and qc['stat_coverage']['ht_home']==1
    assert good[0]['ht_home'] is None
    bad=check_rows('results',h,good+[good[0]])
    assert not bad['passed'] and bad['duplicate_keys']==1
    oh=['match_id','bookmaker','home','draw','away','home_open','draw_open','away_open']
    oq=check_optional_rows('odds_1x2',oh,[{'match_id':'m1','bookmaker':'bet365','home':'2.1','draw':'3.2','away':'3.4','home_open':'2.0','draw_open':'3.3','away_open':'3.5'}])
    assert oq['passed'] and oq['rows']==1
    mh=['match_id','bookmaker','market','scope','selection','odds','odds_open']
    mq=check_optional_rows('odds_markets',mh,[{'match_id':'m1','bookmaker':'Betano','market':'over_under','scope':'full_time','selection':'over','odds':'1.9','odds_open':'1.8'}])
    assert mq['passed']
    return 'PASS: league-index parsing, core QC, NULL preservation, odds schema/price QC, duplicate checks'

if __name__=='__main__':
    p=argparse.ArgumentParser(description='WBR 2026/27 research importer with optional odds')
    p.add_argument('--out',default='WBR_2026_27_data_v116')
    p.add_argument('--league',action='append',help='Folder code; repeatable')
    p.add_argument('--all-index',action='store_true',help='Discover every competition in upstream LEAGUE_INDEX (research only)')
    p.add_argument('--self-test',action='store_true')
    a=p.parse_args()
    if a.self_test: print(self_test()); raise SystemExit(0)
    league_map=dict(LEAGUES)
    if a.all_index:
        index=fetch(INDEX_URL).decode('utf-8-sig')
        league_map=discover_leagues(index)
        (Path(a.out)).mkdir(parents=True,exist_ok=True)
        (Path(a.out)/'LEAGUE_INDEX_snapshot_2627.md').write_text(index,encoding='utf-8')
    unknown=[x for x in (a.league or []) if x not in league_map]
    if unknown: raise SystemExit('Unknown league folder(s): '+', '.join(unknown))
    result=run(Path(a.out),league_map,a.league)
    print(json.dumps(result['summary'],ensure_ascii=False,indent=2))
