"""Provider-neutral WBR odds radar: validate, deduplicate and compare quotes."""
from __future__ import annotations
from datetime import datetime, timezone

def _num(value):
    try: return float(value)
    except (TypeError,ValueError): return None

def _time(value):
    if not value: return None
    try:
        dt=datetime.fromisoformat(str(value).replace("Z","+00:00"))
        if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (TypeError,ValueError): return None

def _market_key(q):
    return (str(q.get("wbr_match_id") or ""),str(q.get("market_id") or q.get("market") or "").casefold(),
            str(q.get("period") or "").casefold(),str(q.get("line") if q.get("line") is not None else ""),
            str(q.get("selection_id") or q.get("selection") or q.get("outcome") or "").casefold())

def build_odds_radar(quotes, now_utc=None, max_age_seconds=None):
    if not isinstance(quotes,list): raise ValueError("quotes must be a list")
    now=_time(now_utc) if now_utc else datetime.now(timezone.utc)
    valid=[]; rejected=[]; stale=0
    for idx,q in enumerate(quotes):
        if not isinstance(q,dict):
            rejected.append({"index":idx,"reason":"NOT_OBJECT"}); continue
        price=_num(q.get("odds_decimal",q.get("odds")))
        if price is None or price <= 1.0:
            rejected.append({"index":idx,"reason":"INVALID_DECIMAL_ODDS"}); continue
        if q.get("suspended") is True or q.get("is_suspended") is True:
            rejected.append({"index":idx,"reason":"SUSPENDED"}); continue
        if not q.get("wbr_match_id"):
            rejected.append({"index":idx,"reason":"UNMATCHED_FIXTURE"}); continue
        observed=_time(q.get("observed_at_utc") or q.get("timestamp"))
        age=None if observed is None else max(0,int((now-observed).total_seconds()))
        if max_age_seconds is not None and (age is None or age > max_age_seconds):
            stale+=1; rejected.append({"index":idx,"reason":"STALE_OR_MISSING_TIMESTAMP","age_seconds":age}); continue
        row=dict(q); row["odds_decimal"]=price; row["age_seconds"]=age
        row["provider"]=q.get("provider") or q.get("source") or "unknown"
        valid.append(row)
    groups={}
    for q in valid: groups.setdefault(_market_key(q),[]).append(q)
    markets=[]
    for key,rows in groups.items():
        rows.sort(key=lambda x:(-x["odds_decimal"],str(x.get("provider"))))
        markets.append({"wbr_match_id":key[0],"market_id":key[1],"period":key[2],
          "line":key[3],"selection":key[4],"quote_count":len(rows),
          "best_odds":rows[0]["odds_decimal"],"best_provider":rows[0]["provider"],
          "best_bookmaker":rows[0].get("bookmaker"),
          "best_observed_at_utc":rows[0].get("observed_at_utc"),
          "quotes":rows})
    markets.sort(key=lambda x:(x["wbr_match_id"],x["market_id"],x["selection"]))
    return {"quote_count":len(valid),"market_selection_count":len(markets),
      "rejected_count":len(rejected),"stale_count":stale,"markets":markets,
      "rejected":rejected,
      "policy":"Best decimal price only among valid, unsuspended, canonically matched quotes. No model probability or EV is inferred."}
