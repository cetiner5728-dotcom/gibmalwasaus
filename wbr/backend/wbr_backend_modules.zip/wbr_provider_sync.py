#!/usr/bin/env python3
"""Fetch one daily SportAPI fixture snapshot and one MoviOdds odds snapshot.

Secrets are read only from environment variables. This script does not run
automatically and never prints secret values. Raw provider responses are
archived separately; normalized snapshots feed the read-only WBR bridge.
"""
from __future__ import annotations
import argparse, datetime as dt, gzip, json, os, sys, urllib.error, urllib.request, urllib.parse
from pathlib import Path
from typing import Any

ROOT = Path(os.environ.get("WBR_DATA_DIR", "./data")).resolve()
RAW = ROOT / "raw"
SPORTAPI_BASE = "https://sportapi.ai/api"
SPORTSCORE_BASE = "https://sportscore.com/api/v1"
MOVIODDS_BASE = "https://moviodds.com"

def request_json(url: str, headers: dict[str, str]) -> tuple[Any, dict[str, str]]:
    req = urllib.request.Request(url, headers={"Accept":"application/json","Accept-Encoding":"gzip","User-Agent":"WBR-provider-sync/1.0",**headers})
    with urllib.request.urlopen(req, timeout=45) as response:
        body=response.read()
        if response.headers.get("Content-Encoding","").lower()=="gzip":
            body=gzip.decompress(body)
        return json.loads(body.decode("utf-8")), dict(response.headers.items())

def rows_from(payload: Any, *keys: str) -> list[dict]:
    if isinstance(payload,list): return [x for x in payload if isinstance(x,dict)]
    if isinstance(payload,dict):
        for key in keys:
            value=payload.get(key)
            if isinstance(value,list): return [x for x in value if isinstance(x,dict)]
        data=payload.get("data")
        if isinstance(data,list): return [x for x in data if isinstance(x,dict)]
    return []

def sportapi_fixtures(date: str, key: str) -> tuple[list[dict], dict]:
    payload, headers=request_json(f"{SPORTAPI_BASE}/fixtures/date/{date}", {"X-Api-Key":key})
    source_rows=rows_from(payload,"fixtures","data")
    result=[]
    retrieved=dt.datetime.now(dt.timezone.utc).isoformat()
    for x in source_rows:
        result.append({
            "id":str(x.get("id") or ""),
            "source":"SportAPI.ai",
            "provider":"SportAPI.ai",
            "provider_event_id":x.get("id"),
            "sport":"Football",
            "competition":x.get("league_name") or x.get("league") or None,
            "league_id":x.get("league_id"),
            "league_country":x.get("league_zone") or x.get("league_geo") or None,
            "kickoff":x.get("kickoff_utc") or x.get("datetime") or x.get("date"),
            "homeTeam":x.get("home_team") or x.get("homeTeam"),
            "awayTeam":x.get("away_team") or x.get("awayTeam"),
            "home_team_id":x.get("home_id"),
            "away_team_id":x.get("away_id"),
            "home_logo":x.get("home_logo"),
            "away_logo":x.get("away_logo"),
            "score":(f'{x.get("home_score")}:{x.get("away_score")}' if x.get("home_score") is not None and x.get("away_score") is not None else None),
            "home_score":x.get("home_score"),
            "away_score":x.get("away_score"),
            "status":x.get("status"),
            "minute":x.get("minute"),
            "retrieved_at_utc":retrieved,
            "raw_available_fields":sorted(x.keys())
        })
    return result, {"provider":"SportAPI.ai","status":"ok","retrieved_at_utc":retrieved,"rows":len(result),"http_etag":headers.get("ETag")}


def sportscore_fixtures(date: str, sport: str) -> tuple[list[dict], dict]:
    """Fetch one UTC day from SportScore and normalize documented API aliases.

    Supports both /api/v1/fixtures/ fields and the public widget match shape
    (home, away, time, status_text, slug). Only fields actually present upstream
    are populated; no scores, IDs, competitions or lineups are inferred.
    """
    if sport not in {"football", "basketball", "cricket", "tennis"}:
        raise ValueError(f"Unsupported SportScore sport: {sport}")
    query = urllib.parse.urlencode({"sport": sport, "date": date, "limit": 200})
    payload, headers = request_json(f"{SPORTSCORE_BASE}/fixtures/?{query}", {})
    source_rows = rows_from(payload, "matches", "fixtures", "results", "data")
    retrieved = dt.datetime.now(dt.timezone.utc).isoformat()
    result = []
    for x in source_rows:
        native = x.get("id") or x.get("match_id") or x.get("fixture_id") or x.get("slug")
        home = x.get("home_team") or x.get("homeTeam") or x.get("home")
        away = x.get("away_team") or x.get("awayTeam") or x.get("away")
        if isinstance(home, dict):
            home_name = home.get("name") or home.get("title")
            home_id = home.get("id")
            home_logo = home.get("logo") or home.get("logo_url")
        else:
            home_name, home_id = home, x.get("home_id")
            home_logo = x.get("home_logo")
        if isinstance(away, dict):
            away_name = away.get("name") or away.get("title")
            away_id = away.get("id")
            away_logo = away.get("logo") or away.get("logo_url")
        else:
            away_name, away_id = away, x.get("away_id")
            away_logo = x.get("away_logo")
        comp = x.get("competition") or x.get("league") or x.get("tournament")
        if isinstance(comp, dict):
            comp_name = comp.get("name") or comp.get("title")
            comp_id = comp.get("id") or comp.get("slug")
        else:
            comp_name, comp_id = comp, x.get("competition_id") or x.get("league_id")
        kickoff = (x.get("kickoff_utc") or x.get("kickoff") or x.get("datetime")
                   or x.get("time") or x.get("date"))
        status = x.get("status") or x.get("state") or x.get("status_text") or "unknown"
        hs = x.get("home_score", x.get("score_home"))
        aws = x.get("away_score", x.get("score_away"))
        score = x.get("score")
        if isinstance(score, dict):
            hs = score.get("home", hs); aws = score.get("away", aws)
        elif isinstance(score, str) and score.strip():
            score_text = score.strip().replace("–", ":").replace("-", ":")
        else:
            score_text = None
        if isinstance(score, str) and score.strip():
            normalized_score = score_text
        elif hs is not None and aws is not None:
            normalized_score = f"{hs}:{aws}"
        else:
            normalized_score = None
        result.append({
            "id": str(native) if native is not None else "",
            "source": "SportScore", "provider": "SportScore", "provider_name": "SportScore",
            "provider_match_id": str(native) if native is not None else None,
            "sport": sport.title(), "competition": comp_name, "competition_id": comp_id,
            "league_id": comp_id, "homeTeam": home_name, "awayTeam": away_name,
            "home_team_id": home_id, "away_team_id": away_id,
            "kickoff": kickoff, "kickoff_utc": kickoff,
            "home_score": hs, "away_score": aws, "score": normalized_score,
            "status": status, "status_text": x.get("status_text"),
            "minute": x.get("minute") or x.get("elapsed"),
            "home_logo": home_logo, "away_logo": away_logo,
            "retrieved_at_utc": retrieved, "license_tag": "SPORTSCORE_ATTRIBUTION_REQUIRED",
            "raw_available_fields": sorted(x.keys())
        })
    return result, {"provider":"SportScore", "sport":sport, "status":"ok", "retrieved_at_utc":retrieved,
                    "rows":len(result), "http_etag":headers.get("ETag"),
                    "attribution_required":True, "cache_seconds":60}


def moviodds_snapshot(key: str, sport: str) -> tuple[list[dict], dict, Any]:
    # One request per configured sport. Avoid `sport=all` because the provider
    # documents a very large full-board response.
    payload, headers=request_json(f"{MOVIODDS_BASE}/odds?sport={urllib.parse.quote(sport)}", {"X-API-Key":key})
    matches=rows_from(payload,"matches")
    odds=[]; retrieved=dt.datetime.now(dt.timezone.utc).isoformat()
    for match in matches:
        fixture_id=str(match.get("id") or "")
        for q in (match.get("quotes") or []):
            if not isinstance(q,dict): continue
            odds.append({
                "source":"MoviOdds","provider":"MoviOdds","bookmaker":"bet365",
                "match_id":str(q.get("fixture_id") or fixture_id),
                "match":f'{match.get("home") or ""} vs {match.get("away") or ""}'.strip(),
                "sport":match.get("sport") or sport,
                "competition":match.get("league"),
                "kickoff":match.get("kickoff_utc"),
                "in_play":match.get("in_play"),
                "score":match.get("score"),
                "market_group_id":q.get("group_id"),
                "market_id":q.get("market_id"),
                "selection_id":q.get("sel_id"),
                "market":q.get("market") or q.get("group_name") or q.get("market_key"),
                "selection":q.get("label") or q.get("side") or q.get("outcome"),
                "side":q.get("side"),"line":q.get("line"),"handicap":q.get("handicap"),
                "odds":q.get("odds_dec"),"observed_at_utc":q.get("ts") or retrieved,
                "retrieved_at_utc":retrieved,
                "suspended":q.get("suspended")
            })
    status={"provider":"MoviOdds","status":"ok","sport":sport,"retrieved_at_utc":retrieved,
            "matches":len(matches),"quotes":len(odds),"http_etag":headers.get("ETag"),
            "warming":bool(payload.get("warming")) if isinstance(payload,dict) else False}
    return odds,status,payload

def read_list(path: Path) -> list[dict]:
    try:
        obj=json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj,list) else []
    except (OSError,ValueError): return []

def write_json(path: Path, value: Any):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    tmp.replace(path)

def upsert(existing: list[dict], incoming: list[dict], key_fields: tuple[str,...]) -> list[dict]:
    keyed={}
    for row in existing+incoming:
        key=tuple(str(row.get(k) or "") for k in key_fields)
        if any(key): keyed[key]=row
    return list(keyed.values())

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--date",default=dt.datetime.now(dt.timezone.utc).date().isoformat())
    ap.add_argument("--moviodds-sports",default=os.environ.get("MOVIODDS_SPORTS","soccer"),help="Comma-separated provider sport keys; default soccer")
    ap.add_argument("--sportscore-sports",default=os.environ.get("SPORTSCORE_SPORTS","football,basketball"),help="SportScore sports; default football,basketball")
    args=ap.parse_args()
    ROOT.mkdir(parents=True,exist_ok=True); RAW.mkdir(parents=True,exist_ok=True)
    statuses=[]; errors=[]
    sk=os.environ.get("SPORTAPI_API_KEY","").strip()
    if sk:
        try:
            rows,status=sportapi_fixtures(args.date,sk)
            write_json(RAW/f"sportapi_fixtures_{args.date}.json",rows)
            write_json(ROOT/"matches.json",upsert(read_list(ROOT/"matches.json"),rows,("source","id")))
            statuses.append(status)
        except Exception as e: errors.append({"provider":"SportAPI.ai","error":f"{type(e).__name__}: {e}"})
    else: statuses.append({"provider":"SportAPI.ai","status":"not_configured","reason":"SPORTAPI_API_KEY missing"})
    for sport in [x.strip() for x in args.sportscore_sports.split(",") if x.strip()]:
        try:
            rows,status=sportscore_fixtures(args.date,sport)
            write_json(RAW/f"sportscore_{sport}_{args.date}.json",rows)
            write_json(ROOT/"matches.json",upsert(read_list(ROOT/"matches.json"),rows,("source","id")))
            statuses.append(status)
        except Exception as e:
            errors.append({"provider":"SportScore","sport":sport,"error":f"{type(e).__name__}: {e}"})
    mk=os.environ.get("MOVIODDS_API_KEY","").strip()
    if mk:
        for sport in [x.strip() for x in args.moviodds_sports.split(",") if x.strip()]:
            try:
                rows,status,raw=moviodds_snapshot(mk,sport)
                write_json(RAW/f"moviodds_{sport}_{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.json",raw)
                write_json(ROOT/"odds.json",upsert(read_list(ROOT/"odds.json"),rows,("source","match_id","market_group_id","market_id","selection_id")))
                statuses.append(status)
            except Exception as e: errors.append({"provider":"MoviOdds","sport":sport,"error":f"{type(e).__name__}: {e}"})
    else: statuses.append({"provider":"MoviOdds","status":"not_configured","reason":"MOVIODDS_API_KEY missing"})
    report={"generated_at":dt.datetime.now(dt.timezone.utc).isoformat(),"sources":statuses,"errors":errors,
            "note":"Provider status reflects this explicit sync attempt only. No status is inferred for unconfigured providers."}
    write_json(ROOT/"source_status.json",report)
    print(json.dumps({"data_dir":str(ROOT),"source_status":report,
                      "matches_total":len(read_list(ROOT/"matches.json")),
                      "odds_total":len(read_list(ROOT/"odds.json"))},ensure_ascii=False,indent=2))
    return 1 if errors else 0

if __name__=="__main__":
    import urllib.parse
    raise SystemExit(main())
