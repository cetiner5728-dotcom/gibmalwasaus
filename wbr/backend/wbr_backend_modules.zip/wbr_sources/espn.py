"""ESPN public scoreboard payload normalizer; transport is supplied by caller."""
from __future__ import annotations
from datetime import datetime, timezone

def _iso(v):
    if not v: return None
    try:
        d=datetime.fromisoformat(str(v).replace('Z','+00:00'))
        if d.tzinfo is None: d=d.replace(tzinfo=timezone.utc)
        return d.astimezone(timezone.utc).isoformat().replace('+00:00','Z')
    except (ValueError,TypeError): return None

def normalize_event(e):
    if not isinstance(e,dict): raise ValueError('event_not_object')
    comps=e.get('competitions') or []
    c=comps[0] if comps and isinstance(comps[0],dict) else {}
    competitors=c.get('competitors') or []
    home=next((x for x in competitors if x.get('homeAway')=='home'),None)
    away=next((x for x in competitors if x.get('homeAway')=='away'),None)
    if not home or not away: raise ValueError('missing_home_away_competitors')
    def score(x):
        try: return int(float(x.get('score'))) if x.get('score') not in (None,'') else None
        except (ValueError,TypeError): return None
    status=((c.get('status') or {}).get('type') or {})
    state=status.get('state')
    return {'provider':'ESPN','provider_match_key':str(e.get('id')) if e.get('id') is not None else None,
      'sport':'football','season':str((e.get('season') or {}).get('year') or '' ) or None,
      'competition_name':((e.get('season') or {}).get('name') or (e.get('league') or {}).get('name')),
      'kickoff_utc':_iso(e.get('date')),
      'home_team':(home.get('team') or {}).get('displayName') or (home.get('team') or {}).get('name'),
      'away_team':(away.get('team') or {}).get('displayName') or (away.get('team') or {}).get('name'),
      'home_score':score(home),'away_score':score(away),
      'status':'finished' if state=='post' else ('live' if state=='in' else 'scheduled'),
      'raw_provider_fields':{'event_id':e.get('id'),'status':status,'venue':c.get('venue')}}

def normalize_response(payload):
    if not isinstance(payload,dict): raise ValueError('ESPN payload must be an object')
    events=payload.get('events') or []
    rows=[]; rejected=[]
    for i,e in enumerate(events):
        try: rows.append(normalize_event(e))
        except Exception as ex: rejected.append({'index':i,'error':str(ex)})
    return {'provider':'ESPN','matches':rows,'count':len(rows),'rejected':rejected}
