"""CSV fixture importer for OpenFootball/football-data style downloaded files."""
from __future__ import annotations
import csv, io
from datetime import datetime, timezone

def _get(row,*names):
    lower={str(k).strip().casefold():v for k,v in row.items()}
    for n in names:
        v=lower.get(n.casefold())
        if v not in (None,''): return str(v).strip()
    return None

def _date(v):
    if not v: return None
    for fmt in ('%Y-%m-%d','%d/%m/%Y','%d.%m.%Y','%Y%m%d'):
        try: return datetime.strptime(v[:10],fmt).replace(tzinfo=timezone.utc).isoformat().replace('+00:00','Z')
        except ValueError: pass
    try:
        d=datetime.fromisoformat(v.replace('Z','+00:00'))
        if d.tzinfo is None: d=d.replace(tzinfo=timezone.utc)
        return d.astimezone(timezone.utc).isoformat().replace('+00:00','Z')
    except ValueError: return None

def normalize_csv(text, provider='OpenFootball', season=None, competition=None):
    if not isinstance(text,str): raise ValueError('CSV content must be text')
    reader=csv.DictReader(io.StringIO(text)); rows=[]; rejected=[]
    for i,r in enumerate(reader):
        home=_get(r,'HomeTeam','Home','home_team','home'); away=_get(r,'AwayTeam','Away','away_team','away')
        kickoff=_date(_get(r,'Date','date','kickoff','datetime'))
        if not home or not away or not kickoff:
            rejected.append({'row':i+2,'error':'missing_team_or_valid_date'}); continue
        def num(*keys):
            v=_get(r,*keys)
            try: return int(float(v)) if v is not None else None
            except ValueError: return None
        ident=_get(r,'MatchID','id','fixture_id')
        rows.append({'provider':provider,'provider_match_key':ident or f'{competition or "unknown"}:{kickoff}:{home}:{away}',
          'sport':'football','season':season or _get(r,'Season','season'),'competition_name':competition or _get(r,'League','Div','competition'),
          'kickoff_utc':kickoff,'home_team':home,'away_team':away,
          'home_score':num('FTHG','HomeGoals','home_score'),'away_score':num('FTAG','AwayGoals','away_score'),
          'status':'finished' if num('FTHG','HomeGoals','home_score') is not None and num('FTAG','AwayGoals','away_score') is not None else 'scheduled',
          'raw_provider_fields':{'csv_row':i+2}})
    return {'provider':provider,'matches':rows,'count':len(rows),'rejected':rejected}
