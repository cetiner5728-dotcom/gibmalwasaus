"""MoviOdds REST adapter for WBR.

Server-side only. Reads MOVIODDS_API_KEY from the environment.
No API key is embedded in source code or browser JavaScript.
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Iterable


BASE_URL = "https://moviodds.com"


class MoviOddsError(RuntimeError):
    pass


@dataclass
class NormalizedQuote:
    source: str
    bookmaker: str
    fixture_source_id: str
    market_source_id: str | None
    market_group_id: str | None
    selection_source_id: str | None
    selection: str | None
    odds_decimal: float | None
    captured_at: str | None
    suspended: bool
    raw: dict[str, Any]


@dataclass
class NormalizedFixture:
    source: str
    source_fixture_id: str
    sport: str
    league: str | None
    home: str
    away: str
    kickoff_utc: str | None
    in_play: bool
    polled_at: str | None
    quotes: list[NormalizedQuote]
    raw: dict[str, Any]


def _iso_or_none(value: Any) -> str | None:
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, timezone.utc).isoformat()
    return str(value)


def _decimal(value: Any) -> float | None:
    try:
        number = float(value)
        return number if number > 1.0 else None
    except (TypeError, ValueError):
        return None


class MoviOddsClient:
    """Small, dependency-free REST client with retry/backoff for transient errors."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = BASE_URL,
        timeout: int = 25,
        max_retries: int = 2,
    ):
        self.api_key = api_key or os.getenv("MOVIODDS_API_KEY")
        if not self.api_key:
            raise MoviOddsError(
                "MOVIODDS_API_KEY fehlt. API-Key serverseitig als Umgebungsvariable setzen."
            )
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

    def _get_json(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        query = urllib.parse.urlencode(
            {k: v for k, v in (params or {}).items() if v is not None}
        )
        url = f"{self.base_url}{path}" + (f"?{query}" if query else "")
        request = urllib.request.Request(
            url,
            headers={
                "X-API-Key": self.api_key,
                "Accept": "application/json",
                "Accept-Encoding": "gzip",
                "User-Agent": "WBR-MoviOdds-Adapter/0.1",
            },
        )
        for attempt in range(self.max_retries + 1):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    status = response.status
                    body = response.read()
                    if status != 200:
                        raise MoviOddsError(f"MoviOdds HTTP {status}")
                    # urllib does not transparently decode gzip in every environment.
                    if response.headers.get("Content-Encoding") == "gzip":
                        import gzip
                        body = gzip.decompress(body)
                    return json.loads(body.decode("utf-8"))
            except urllib.error.HTTPError as exc:
                body = exc.read(1000).decode("utf-8", "replace")
                if exc.code in (429, 502, 503, 504) and attempt < self.max_retries:
                    retry_after = exc.headers.get("Retry-After")
                    delay = float(retry_after) if retry_after else min(2 ** attempt, 8)
                    time.sleep(delay)
                    continue
                if exc.code in (401, 403):
                    raise MoviOddsError(
                        f"MoviOdds Auth-Fehler HTTP {exc.code}; API-Key prüfen/erneuern."
                    ) from exc
                raise MoviOddsError(f"MoviOdds HTTP {exc.code}: {body}") from exc
            except (TimeoutError, urllib.error.URLError) as exc:
                if attempt < self.max_retries:
                    time.sleep(min(2 ** attempt, 8))
                    continue
                raise MoviOddsError(f"MoviOdds-Verbindungsfehler: {exc}") from exc
        raise MoviOddsError("MoviOdds-Anfrage nach Wiederholungen fehlgeschlagen.")

    def get_odds(
        self,
        sport: str = "soccer",
        in_play: bool | None = None,
        groups: Iterable[str | int] | None = None,
    ) -> list[NormalizedFixture]:
        params: dict[str, Any] = {"sport": sport}
        if in_play is not None:
            params["in_play"] = 1 if in_play else 0
        if groups:
            params["groups"] = ",".join(str(x) for x in groups)

        payload = self._get_json("/odds", params)
        rows = payload.get("matches", [])
        fixtures: list[NormalizedFixture] = []
        for row in rows:
            fixture_id = str(row.get("id", ""))
            if not fixture_id:
                continue
            quote_rows = row.get("quotes") or []
            quotes = [
                NormalizedQuote(
                    source="moviodds",
                    bookmaker="bet365",
                    fixture_source_id=fixture_id,
                    market_source_id=str(q["market_id"]) if q.get("market_id") is not None else None,
                    market_group_id=str(q["group_id"]) if q.get("group_id") is not None else None,
                    selection_source_id=str(q["sel_id"]) if q.get("sel_id") is not None else None,
                    selection=q.get("label"),
                    odds_decimal=_decimal(q.get("odds_dec")),
                    captured_at=_iso_or_none(q.get("ts")),
                    suspended=bool(q.get("suspended", False)),
                    raw=q,
                )
                for q in quote_rows
            ]
            fixtures.append(
                NormalizedFixture(
                    source="moviodds",
                    source_fixture_id=fixture_id,
                    sport=sport,
                    league=row.get("league"),
                    home=row.get("home", ""),
                    away=row.get("away", ""),
                    kickoff_utc=_iso_or_none(row.get("kickoff_utc")),
                    in_play=bool(row.get("in_play", False)),
                    polled_at=_iso_or_none(row.get("polled_at")),
                    quotes=quotes,
                    raw=row,
                )
            )
        return fixtures

    @staticmethod
    def to_dict(fixture: NormalizedFixture) -> dict[str, Any]:
        result = asdict(fixture)
        # Preserve raw payload for audit, but mark the source and book explicitly.
        result["data_quality"] = {
            "source": "moviodds",
            "bookmaker": "bet365",
            "verified_live_bookmaker_price": True,
            "requires_freshness_check": True,
            "is_prediction": False,
        }
        return result
