"""OpenLigaDB fixture adapter. No key required; cache/rate limiting belongs to scheduler."""
from __future__ import annotations
from datetime import datetime, timezone

def _iso_utc(value):
    if not value: return None
    try:
        dt=datetime.fromisoformat(str(value).replace("Z","+00:00"))
        if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat().replace("+00:00","Z")
    except (ValueError,TypeError): return None

def normalize_match(match: dict) -> dict:
    if not isinstance(match,dict): raise ValueError("match must be an object")
    teams=match.get("match jaki") or match.get("match") or {}
    team1=match.get("Team1") or {}
    team2=match.get("Team2") or {}
    results=match.get("MatchResults") or []
    latest=next((r for r in reversed(results) if r.get("ResultTypeID")==2),None) or (results[-1] if results else {})
    return {
      "provider":"OpenLigaDB",
      "provider_match_key":str(match.get("MatchID")) if match.get("MatchID") is not None else None,
      "sport":"football",
      "season":str(match.get("LeagueSeason")) if match.get("LeagueSeason") is not None else None,
      "competition_name":(match.get("LeagueName") or match.get("LeagueShortcut")),
      "kickoff_utc":_iso_utc(match.get("MatchDateTimeUTC") or match.get("MatchDateTime")),
      "home_team":team1.get("TeamName"),
      "away_team":team2.get("TeamName"),
      "home_score":latest.get("PointsTeam1"),
      "away_score":latest.get("PointsTeam2"),
      "status":"finished" if match.get("MatchIsFinished") else "scheduled",
      "raw_provider_fields":{"match_id":match.get("MatchID"),"group":match.get("Group"),"results":results}
    }

def normalize_response(payload):
    if not isinstance(payload,list): raise ValueError("OpenLigaDB response must be a list")
    rows=[]; rejected=[]
    for i,item in enumerate(payload):
        try: rows.append(normalize_match(item))
        except Exception as exc: rejected.append({"index":i,"error":str(exc)})
    return {"provider":"OpenLigaDB","matches":rows,"count":len(rows),"rejected":rejected}
