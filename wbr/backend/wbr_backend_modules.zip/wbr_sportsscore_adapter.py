"""WBR SportScore payload adapter. Pure normalization; HTTP transport is deliberately separate."""
from datetime import datetime, timezone

def _first(obj, *keys):
    for key in keys:
        value = obj.get(key) if isinstance(obj, dict) else None
        if value not in (None, ""):
            return value
    return None

def _team(value):
    if isinstance(value, dict):
        return {"id": _first(value, "id", "team_id", "uid"), "name": _first(value, "name", "title", "short_name"), "logo": _first(value, "logo", "image", "logo_url")}
    if isinstance(value, str):
        return {"id": None, "name": value, "logo": None}
    return {"id": None, "name": None, "logo": None}

def normalize_fixture(item, retrieved_at=None):
    """Map one SportScore fixture/widget match into WBR's shared match shape."""
    if not isinstance(item, dict):
        raise TypeError("fixture must be an object")
    home = _team(_first(item, "home", "homeTeam", "home_team", "team1"))
    away = _team(_first(item, "away", "awayTeam", "away_team", "team2"))
    tournament = _first(item, "tournament", "league", "competition") or {}
    if not isinstance(tournament, dict): tournament = {"name": str(tournament)}
    score = _first(item, "score", "scores", "result")
    if isinstance(score, dict):
        h = _first(score, "home", "home_score", "team1")
        a = _first(score, "away", "away_score", "team2")
        score_text = f"{h}:{a}" if h is not None and a is not None else None
    elif isinstance(score, (list, tuple)) and len(score) >= 2:
        score_text = f"{score[0]}:{score[1]}"
    else: score_text = str(score) if score is not None else None
    status = _first(item, "status", "status_text", "state")
    if isinstance(status, dict): status = _first(status, "name", "description", "code")
    kickoff = _first(item, "time", "start_time", "kickoff", "kickoff_utc", "date")
    return {
      "id": _first(item, "id", "match_id", "fixture_id", "slug"),
      "provider_match_id": _first(item, "id", "match_id", "fixture_id", "slug"),
      "sport": _first(item, "sport", "sport_name") or "Unknown",
      "competition_name": _first(tournament, "name", "title", "slug") or _first(item, "competition_name", "league_name"),
      "kickoff_utc": kickoff, "homeTeam": home["name"], "awayTeam": away["name"],
      "home_team_id": home["id"], "away_team_id": away["id"],
      "home_logo": home["logo"], "away_logo": away["logo"],
      "score": score_text, "status": status, "source": "SportScore",
      "retrieved_at_utc": retrieved_at or datetime.now(timezone.utc).isoformat(),
      "attribution": "Powered by SportScore"
    }

def normalize_payload(payload, retrieved_at=None):
    """Accept list responses and common API envelopes; return normalized fixtures."""
    if isinstance(payload, list): items = payload
    elif isinstance(payload, dict):
        items = _first(payload, "fixtures", "matches", "events", "data", "results")
        if isinstance(items, dict): items = _first(items, "fixtures", "matches", "events", "data")
    else: items = None
    if not isinstance(items, list):
        raise ValueError("No fixture list found in SportScore payload")
    return [normalize_fixture(x, retrieved_at) for x in items]
