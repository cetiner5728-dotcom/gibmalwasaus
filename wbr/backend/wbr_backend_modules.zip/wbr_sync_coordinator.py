"""One deterministic sync pass for normalized fixture batches from multiple providers."""
from __future__ import annotations
from wbr_fixture_store import merge_fixture_snapshot
from wbr_canonical_schedule import build_canonical_schedule

def apply_provider_batches(existing_matches, batches, tolerance_minutes=5):
    if not isinstance(batches,list):
        raise ValueError("batches must be a list")
    current=existing_matches if existing_matches is not None else []
    reports=[]
    seen=set()
    for batch in batches:
        if not isinstance(batch,dict):
            reports.append({"provider":"unknown","status":"REJECTED","reason":"batch_not_object"})
            continue
        provider=str(batch.get("provider") or "").strip()
        rows=batch.get("matches")
        if not provider or not isinstance(rows,list):
            reports.append({"provider":provider or "unknown","status":"REJECTED","reason":"missing_provider_or_matches"})
            continue
        key=provider.casefold()
        if key in seen:
            reports.append({"provider":provider,"status":"REJECTED","reason":"duplicate_provider_batch"})
            continue
        seen.add(key)
        result=merge_fixture_snapshot(current,rows,provider)
        current=result["matches"]
        reports.append({"provider":provider,"status":"APPLIED","received":len(rows),
                        "added":result["added"],"updated":result["updated"],
                        "unresolved":result["unresolved"]})
    canonical=build_canonical_schedule(current,tolerance_minutes=tolerance_minutes)
    return {"matches":current,"provider_reports":reports,
            "provider_count":len([r for r in reports if r["status"]=="APPLIED"]),
            "canonical_schedule":canonical}
