"""Unified WBR fixture + odds pipeline. Pure transformation layer; persistence stays with app.py."""
from __future__ import annotations
from wbr_sync_coordinator import apply_provider_batches
from wbr_moviodds_ingest import ingest_payload
from wbr_moviodds_store import merge_moviodds
from wbr_odds_radar import build_odds_radar

def run_unified_pipeline(existing_matches, fixture_batches, existing_odds,
                        moviodds_payload=None, season_by_league=None,
                        odds_max_age_seconds=None, now_utc=None):
    """Apply provider fixture snapshots, link MoviOdds quotes, then build odds radar.

    Does not perform network requests or write files. Caller persists returned
    matches/odds/reports atomically using the existing backend storage helpers.
    """
    if existing_odds is not None and not isinstance(existing_odds,list):
        raise ValueError("existing_odds must be a JSON list")
    fixture_result=apply_provider_batches(existing_matches,fixture_batches)
    matches=fixture_result["matches"]
    movi_report=None
    odds=list(existing_odds or [])
    unmatched=[]
    if moviodds_payload is not None:
        movi_report=ingest_payload(moviodds_payload,matches,season_by_league=season_by_league)
        merged=merge_moviodds(odds,movi_report)
        odds=merged["odds"]
        unmatched=merged["unmatched_moviodds"]
    radar=build_odds_radar(odds,now_utc=now_utc,max_age_seconds=odds_max_age_seconds)
    return {
      "matches":matches,
      "canonical_schedule":fixture_result["canonical_schedule"],
      "provider_reports":fixture_result["provider_reports"],
      "provider_count":fixture_result["provider_count"],
      "odds":odds,
      "odds_radar":radar,
      "moviodds_report":movi_report,
      "unmatched_moviodds":unmatched,
      "summary":{
        "fixture_count":len(matches),
        "canonical_fixture_count":fixture_result["canonical_schedule"]["count"],
        "odds_count":len(odds),
        "radar_market_selection_count":radar["market_selection_count"],
        "unmatched_moviodds_count":len(unmatched)
      }
    }
