#!/usr/bin/env python3
"""Convert WBR V1.16 CSV snapshots to backend JSON without inventing joins."""
from __future__ import annotations
import argparse, csv, json
from datetime import datetime, timezone
from pathlib import Path

SEASON = "2026/27"
SOURCE = "open-matchday"
LICENSE = "NON-COMMERCIAL / informational research only"

def rows(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def val(row, key):
    x = row.get(key)
    return x if x not in ("", None) else None

def num(x):
    if x in (None, ""): return None
    try:
        n=float(x)
        return n if 0 < n < 100000 else None
    except (TypeError, ValueError):
        return None

def convert(data_dir: Path):
    odds=[]; matches=[]; report={"source":SOURCE,"season":SEASON,"generated_at_utc":datetime.now(timezone.utc).isoformat(),
      "license":LICENSE,"warnings":["Daily research snapshot, not live or in-play data.",
      "No cross-provider or fuzzy match joins are performed.",
      "Upstream odds snapshots are not a historical closing-line archive."]}
    for fp in sorted(data_dir.glob("*_fixtures_2627.csv")):
        comp=fp.name[:-len("_fixtures_2627.csv")]
        for r in rows(fp):
            matches.append({
              "provider":SOURCE,"provider_match_id":val(r,"match_id"),
              "competition_id":comp,"competition":comp,"season":SEASON,
              "date":val(r,"date"),"kickoff":val(r,"date"),
              "home":val(r,"home"),"away":val(r,"away"),
              "status":None,"home_score":None,"away_score":None,
              "source_license":LICENSE,"retrieved_at_utc":None
            })
    for fp in sorted(data_dir.glob("*_odds_1x2_2627.csv")):
        comp=fp.name[:-len("_odds_1x2_2627.csv")]
        for r in rows(fp):
            for selection, field, opening in (
              ("home","home","home_open"),("draw","draw","draw_open"),("away","away","away_open")):
                price=num(val(r,field))
                if price is None: continue
                odds.append({
                  "provider":SOURCE,"provider_match_id":val(r,"match_id"),
                  "competition_id":comp,"season":SEASON,
                  "bookmaker":val(r,"bookmaker"),"market":"1x2","scope":"full_time",
                  "selection":selection,"line":None,"odds":price,
                  "odds_open":num(val(r,opening)),"observed_at_utc":None,
                  "source_license":LICENSE,"source_type":"prematch_snapshot"
                })
    for fp in sorted(data_dir.glob("*_odds_markets_2627.csv")):
        comp=fp.name[:-len("_odds_markets_2627.csv")]
        for r in rows(fp):
            price=num(val(r,"odds"))
            if price is None: continue
            odds.append({
              "provider":SOURCE,"provider_match_id":val(r,"match_id"),
              "competition_id":comp,"season":SEASON,
              "bookmaker":val(r,"bookmaker"),"market":val(r,"market"),
              "scope":val(r,"scope"),"selection":val(r,"selection"),
              "line":val(r,"line"),"odds":price,"odds_open":num(val(r,"odds_open")),
              "observed_at_utc":None,"source_license":LICENSE,
              "source_type":"prematch_snapshot"
            })
    (data_dir/"matches.json").write_text(json.dumps(matches,ensure_ascii=False,indent=2),encoding="utf-8")
    (data_dir/"odds.json").write_text(json.dumps(odds,ensure_ascii=False,indent=2),encoding="utf-8")
    report.update({"matches_written":len(matches),"odds_rows_written":len(odds),
      "competitions_with_fixture_files":len(list(data_dir.glob("*_fixtures_2627.csv"))),
      "competitions_with_odds_files":len(set(x["competition_id"] for x in odds)),
      "odds_market_rows":sum(1 for x in odds if x["market"]!="1x2")})
    (data_dir/"WBR_V16_NORMALIZE_REPORT.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    return report

def self_test():
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)
        (p/"ENG_1_fixtures_2627.csv").write_text("date,home,away\n2026-08-01,A,B\n",encoding="utf-8")
        (p/"ENG_1_odds_1x2_2627.csv").write_text("match_id,bookmaker,home,draw,away,home_open,draw_open,away_open\nm1,bet365,2.1,3.2,3.4,2.0,3.3,3.5\n",encoding="utf-8")
        (p/"ENG_1_odds_markets_2627.csv").write_text("match_id,bookmaker,market,scope,selection,line,odds,odds_open\nm1,Betano,over_under,full_time,over,2.5,1.9,1.8\n",encoding="utf-8")
        out=convert(p)
        assert out["matches_written"]==1 and out["odds_rows_written"]==4
        odds=json.loads((p/"odds.json").read_text())
        assert len([x for x in odds if x["market"]=="1x2"])==3
        assert all(x["season"]==SEASON for x in odds)
        assert all(x["provider_match_id"]=="m1" for x in odds)
        assert odds[-1]["line"]=="2.5"
    return "PASS: fixture normalization, 1X2 expansion, market rows, IDs, season, NULL-safe fields"

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-dir",default="data")
    ap.add_argument("--self-test",action="store_true")
    a=ap.parse_args()
    if a.self_test: print(self_test())
    else: print(json.dumps(convert(Path(a.data_dir)),ensure_ascii=False,indent=2))
